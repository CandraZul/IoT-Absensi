#include "images.h"

const ext_img_desc_t images[2] = {
    { "icon_success", &img_icon_success },
    { "icon_fail", &img_icon_fail }
};